export type Product = {
  id: string;
  index: string;
  name: string;
  category: string;
  price: string;
  description: string;
  details: string[];
  image: string;
};

export const products: Product[] = [
  {
    id: "jacket",
    index: "01",
    name: "SHADOW JACKET",
    category: "Outerwear",
    price: "€320",
    description:
      "A weatherproof shell cut from matte ripstop, built with a hidden hood and bonded seams for silhouettes that move at night.",
    details: ["Bonded seam construction", "Matte ripstop shell", "Hidden storm hood", "Reflective stripe, off in daylight"],
    image:
      "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "hoodie",
    index: "02",
    name: "SHADOW HOODIE",
    category: "Mid-layer",
    price: "€165",
    description:
      "Heavyweight double-knit fleece, garment-dyed for a shadow-black finish that deepens with wear.",
    details: ["480gsm double-knit fleece", "Garment-dyed finish", "Raw-cut hem", "Interior chest pocket"],
    image:
      "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "pant",
    index: "03",
    name: "SHADOW PANT",
    category: "Bottoms",
    price: "€180",
    description:
      "Tapered technical trouser with articulated knees and a four-way stretch weave built for the transition between day and drop.",
    details: ["Four-way stretch weave", "Articulated knee panels", "Tapered leg, elastic cuff", "Concealed zip pockets"],
    image:
      "https://images.unsplash.com/photo-1517438476312-10d79c077509?q=80&w=1200&auto=format&fit=crop",
  },
  {
    id: "sneaker",
    index: "04",
    name: "SHADOW SNEAKER",
    category: "Footwear",
    price: "€240",
    description:
      "The silhouette at the center of the capsule. A monochrome upper over a responsive midsole, three stripes cast in low relief.",
    details: ["Responsive foam midsole", "Monofilament mesh upper", "Tonal three-stripe overlay", "Reflective heel tab"],
    image:
      "https://images.unsplash.com/photo-1595950653106-6c9ebd614d3a?q=80&w=1200&auto=format&fit=crop",
  },
];
