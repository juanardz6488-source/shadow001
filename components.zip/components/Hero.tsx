"use client";

import dynamic from "next/dynamic";
import { motion } from "framer-motion";

const SneakerScene = dynamic(() => import("./SneakerScene"), { ssr: false });

const EASE = [0.16, 1, 0.3, 1] as const;

export default function Hero() {
  return (
    <section className="relative flex h-[100svh] w-full items-center justify-center overflow-hidden">
      <div className="pointer-events-none absolute inset-x-0 top-24 z-10 flex flex-col items-center gap-3 text-center">
        <motion.span
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.2, ease: EASE }}
          className="font-mono text-[10px] tracking-widest2 text-ash"
        >
          01 — INTRODUCING
        </motion.span>
        <div className="mask-reveal">
          <motion.h1
            initial={{ y: "100%" }}
            animate={{ y: "0%" }}
            transition={{ duration: 1.3, delay: 0.35, ease: EASE }}
            className="font-display text-[15vw] font-800 leading-[0.82] tracking-tightest text-bone md:text-[7vw]"
          >
            SHADOW//001
          </motion.h1>
        </div>
      </div>

      <div className="absolute inset-0 z-[5]">
        <SneakerScene />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1, delay: 1.4, ease: EASE }}
        className="pointer-events-none absolute inset-x-0 bottom-14 z-10 flex flex-col items-center gap-6"
      >
        <p className="max-w-sm px-6 text-center font-body text-sm font-light leading-relaxed text-silver-dim">
          A capsule cut from darkness. Four pieces. One night only. Built for
          those who move before the light does.
        </p>
        <div className="flex flex-col items-center gap-2">
          <span className="font-mono text-[9px] tracking-widest2 text-ash">
            SCROLL
          </span>
          <motion.div
            className="h-10 w-px bg-gradient-to-b from-silver to-transparent"
            animate={{ scaleY: [0.4, 1, 0.4] }}
            transition={{ duration: 2.2, repeat: Infinity, ease: "easeInOut" }}
            style={{ transformOrigin: "top" }}
          />
        </div>
      </motion.div>

      <div className="pointer-events-none absolute inset-0 z-[6] bg-gradient-to-t from-void via-transparent to-void/40" />
    </section>
  );
}
