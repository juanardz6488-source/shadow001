"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const LETTERS = "CRAFTED".split("");

export default function Crafted() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const letterRefs = useRef<(HTMLSpanElement | null)[]>([]);
  const bgRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const spread = [-38, -22, -10, 0, 10, 22, 38];

      gsap.set(letterRefs.current, { xPercent: 0 });

      const tl = gsap.timeline({
        scrollTrigger: {
          trigger: sectionRef.current,
          start: "top top",
          end: "+=140%",
          scrub: 1,
          pin: true,
        },
      });

      tl.to(
        letterRefs.current,
        {
          xPercent: (i) => spread[i] ?? 0,
          ease: "power2.out",
        },
        0
      )
        .to(
          bgRef.current,
          { opacity: 1, scale: 1, ease: "power2.out" },
          0
        )
        .to(
          letterRefs.current,
          { color: "rgba(242,242,240,0.12)", ease: "power2.out" },
          0.1
        );
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      className="relative z-10 flex h-[100svh] w-full items-center justify-center overflow-hidden bg-void"
    >
      <div
        ref={bgRef}
        className="absolute inset-0 z-0 scale-110 opacity-0"
        style={{
          backgroundImage:
            "url('https://images.unsplash.com/photo-1595341888016-a392ef81b7de?q=80&w=1600&auto=format&fit=crop')",
          backgroundSize: "cover",
          backgroundPosition: "center",
          filter: "grayscale(1) brightness(0.5)",
        }}
      />
      <div className="absolute inset-0 z-[1] bg-gradient-to-t from-void via-void/40 to-void/70" />

      <div className="relative z-10 flex select-none items-center justify-center">
        {LETTERS.map((l, i) => (
          <span
            key={i}
            ref={(el) => {
              letterRefs.current[i] = el;
            }}
            className="font-display text-[16vw] font-800 leading-none tracking-tightest text-bone md:text-[12vw]"
          >
            {l}
          </span>
        ))}
      </div>

      <div className="absolute bottom-14 left-1/2 z-10 -translate-x-1/2 text-center">
        <p className="max-w-md px-6 font-body text-xs font-light leading-relaxed text-silver-dim">
          Every seam considered. Every material tested against the dark.
          SHADOW//001 is built, not printed.
        </p>
      </div>
    </section>
  );
}
