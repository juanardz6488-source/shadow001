"use client";

import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function Preloader({ onDone }: { onDone: () => void }) {
  const [stage, setStage] = useState<"logo" | "title" | "done">("logo");

  useEffect(() => {
    const t1 = setTimeout(() => setStage("title"), 2000);
    const t2 = setTimeout(() => {
      setStage("done");
      onDone();
    }, 4200);
    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
    };
  }, [onDone]);

  return (
    <AnimatePresence>
      {stage !== "done" && (
        <motion.div
          className="fixed inset-0 z-[250] flex flex-col items-center justify-center bg-void"
          exit={{ opacity: 0, transition: { duration: 1.1, ease: EASE } }}
        >
          <div
            className="pointer-events-none absolute inset-0"
            style={{
              background:
                "radial-gradient(circle at 50% 50%, rgba(255,255,255,0.06), transparent 55%)",
            }}
          />

          <AnimatePresence mode="wait">
            {stage === "logo" && (
              <motion.div
                key="logo"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0, transition: { duration: 0.6, ease: EASE } }}
                transition={{ duration: 1.2, ease: EASE }}
                className="flex flex-col items-center gap-4"
              >
                <svg
                  width="34"
                  height="34"
                  viewBox="0 0 60 60"
                  fill="none"
                  className="opacity-90"
                >
                  <path d="M2 46L14 20L20 33L10 46H2Z" fill="#F2F2F0" />
                  <path d="M22 46L34 14L40 27L30 46H22Z" fill="#F2F2F0" />
                  <path d="M42 46L52 27L58 40L54 46H42Z" fill="#F2F2F0" />
                </svg>
                <span className="font-mono text-[9px] tracking-widest2 text-ash">
                  ADIDAS
                </span>
              </motion.div>
            )}

            {stage === "title" && (
              <motion.div
                key="title"
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 0.4 }}
                className="flex flex-col items-center px-6 text-center"
              >
                <div className="mask-reveal">
                  <motion.h1
                    initial={{ y: "110%" }}
                    animate={{ y: "0%" }}
                    transition={{ duration: 1.4, ease: EASE }}
                    className="font-display text-[13vw] font-800 leading-[0.85] tracking-tightest text-bone md:text-[9vw]"
                  >
                    SHADOW//001
                  </motion.h1>
                </div>
                <motion.p
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 1, delay: 0.7, ease: EASE }}
                  className="mt-4 font-mono text-xs tracking-widest2 text-silver-dim"
                >
                  LIMITED DROP.
                </motion.p>
              </motion.div>
            )}
          </AnimatePresence>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
