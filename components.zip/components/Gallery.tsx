"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/dist/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
}

const images = [
  "https://images.unsplash.com/photo-1552346154-21d32810aba3?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1605348532760-6753d2c43329?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1543508282-6319a3e2621f?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1491553895911-0055eca6402d?q=80&w=1200&auto=format&fit=crop",
  "https://images.unsplash.com/photo-1560769629-975ec94e6a86?q=80&w=1200&auto=format&fit=crop",
];

export default function Gallery() {
  const trackRef = useRef<HTMLDivElement>(null);
  const wrapperRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      const track = trackRef.current;
      const wrapper = wrapperRef.current;
      if (!track || !wrapper) return;

      const distance = track.scrollWidth - window.innerWidth;

      gsap.to(track, {
        x: -distance,
        ease: "none",
        scrollTrigger: {
          trigger: wrapper,
          start: "top top",
          end: () => `+=${distance}`,
          scrub: 1,
          pin: true,
          invalidateOnRefresh: true,
        },
      });

      gsap.utils.toArray<HTMLElement>(".gallery-item").forEach((item, i) => {
        gsap.fromTo(
          item.querySelector("img"),
          { scale: 1.25 },
          {
            scale: 1,
            ease: "none",
            scrollTrigger: {
              trigger: item,
              containerAnimation: gsap.getTweensOf(track)[0],
              start: "left right",
              end: "right left",
              scrub: true,
            },
          }
        );
      });
    }, wrapperRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={wrapperRef}
      className="relative z-10 h-[100svh] w-full overflow-hidden bg-void"
    >
      <div className="absolute left-6 top-10 z-20 md:left-16">
        <span className="font-mono text-[10px] tracking-widest2 text-ash">
          03 — IN THE FIELD
        </span>
      </div>

      <div ref={trackRef} className="flex h-full items-center gap-6 pl-[10vw] pr-[10vw]">
        {images.map((src, i) => (
          <div
            key={i}
            data-cursor="drag"
            className={`gallery-item relative h-[62vh] flex-shrink-0 overflow-hidden rounded-sm border border-white/5 ${
              i % 2 === 0 ? "w-[42vw] self-start mt-4" : "w-[32vw] self-end mb-4"
            } md:h-[65vh]`}
            style={{ minWidth: i % 2 === 0 ? "420px" : "320px" }}
          >
            <img
              src={src}
              alt="Shadow drop campaign"
              className="h-full w-full object-cover grayscale"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-void/60 via-transparent to-transparent" />
            <span className="absolute bottom-4 left-4 font-mono text-[10px] tracking-widest2 text-ash">
              {String(i + 1).padStart(2, "0")} / {String(images.length).padStart(2, "0")}
            </span>
          </div>
        ))}
      </div>
    </section>
  );
}
