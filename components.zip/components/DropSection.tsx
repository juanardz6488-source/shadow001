"use client";

import { motion } from "framer-motion";
import ProductCard from "./ProductCard";
import { products, type Product } from "@/lib/data";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function DropSection({
  onOpen,
}: {
  onOpen: (p: Product) => void;
}) {
  return (
    <section className="relative z-10 px-6 py-32 md:px-16">
      <div className="mb-16 flex flex-col gap-4">
        <motion.span
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="font-mono text-[10px] tracking-widest2 text-ash"
        >
          02 — THE DROP
        </motion.span>
        <div className="mask-reveal">
          <motion.h2
            initial={{ y: "100%" }}
            whileInView={{ y: "0%" }}
            viewport={{ once: true, amount: 0.6 }}
            transition={{ duration: 1, ease: EASE }}
            className="font-display text-5xl font-800 tracking-tightest text-bone md:text-7xl"
          >
            Four pieces.
          </motion.h2>
        </div>
        <motion.p
          initial={{ opacity: 0, y: 10 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.2 }}
          className="max-w-md font-body text-sm font-light text-silver-dim"
        >
          Every silhouette designed as one system. Select a piece to enter
          its record.
        </motion.p>
      </div>

      <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
        {products.map((p, i) => (
          <div key={p.id} className={i % 2 === 1 ? "md:mt-16" : ""}>
            <ProductCard product={p} onOpen={onOpen} />
          </div>
        ))}
      </div>
    </section>
  );
}
