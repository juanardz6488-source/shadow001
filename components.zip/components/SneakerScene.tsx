"use client";

import { useRef, useMemo } from "react";
import { Canvas, useFrame, useThree } from "@react-three/fiber";
import { Environment, ContactShadows, Float } from "@react-three/drei";
import * as THREE from "three";

/**
 * Stylized procedural sneaker silhouette built from primitives.
 * Swap the <SneakerModel /> body for a real GLTF (useGLTF) once you
 * have licensed 3D footwear assets — geometry hooks are left in place.
 */
function SneakerModel({ pointer }: { pointer: React.MutableRefObject<{ x: number; y: number }> }) {
  const group = useRef<THREE.Group>(null);
  const light = useRef<THREE.SpotLight>(null);

  useFrame((state, delta) => {
    if (!group.current) return;
    group.current.rotation.y += delta * 0.18;
    group.current.rotation.x = THREE.MathUtils.lerp(
      group.current.rotation.x,
      pointer.current.y * 0.25,
      0.05
    );
    group.current.position.x = THREE.MathUtils.lerp(
      group.current.position.x,
      pointer.current.x * 0.35,
      0.05
    );
    if (light.current) {
      light.current.position.x = pointer.current.x * 4;
      light.current.position.y = 3 + pointer.current.y * 1.5;
    }
  });

  return (
    <>
      <spotLight
        ref={light}
        position={[2, 4, 3]}
        angle={0.4}
        penumbra={0.8}
        intensity={40}
        color="#e9eaec"
        castShadow
      />
      <Float speed={1.4} rotationIntensity={0.15} floatIntensity={0.6}>
        <group ref={group} scale={1.15}>
          {/* sole */}
          <mesh position={[0, -0.55, 0]} castShadow receiveShadow>
            <capsuleGeometry args={[0.62, 1.5, 8, 24]} />
            <meshPhysicalMaterial
              color="#0e0e10"
              roughness={0.35}
              metalness={0.1}
              clearcoat={0.6}
            />
          </mesh>
          {/* midsole glow layer */}
          <mesh position={[0, -0.42, 0]} rotation={[0, 0, Math.PI / 2]}>
            <torusGeometry args={[0.64, 0.05, 16, 60]} />
            <meshBasicMaterial color="#c9cace" transparent opacity={0.5} />
          </mesh>
          {/* upper */}
          <mesh position={[0, 0.15, 0]} castShadow>
            <sphereGeometry args={[0.72, 32, 32, 0, Math.PI * 2, 0, Math.PI * 0.6]} />
            <meshPhysicalMaterial
              color="#232326"
              roughness={0.55}
              metalness={0.05}
              clearcoat={0.3}
            />
          </mesh>
          {/* three stripes */}
          {[-0.25, 0, 0.25].map((z, i) => (
            <mesh key={i} position={[0.55, 0.15, z]} rotation={[0, 0, Math.PI / 5]}>
              <boxGeometry args={[0.05, 0.55, 0.08]} />
              <meshStandardMaterial color="#f2f2f0" roughness={0.4} />
            </mesh>
          ))}
          {/* laces ridge */}
          <mesh position={[0.15, 0.42, 0]} rotation={[0.3, 0, 0]}>
            <boxGeometry args={[0.5, 0.06, 0.35]} />
            <meshStandardMaterial color="#3a3a3e" roughness={0.6} />
          </mesh>
        </group>
      </Float>
      <ContactShadows
        position={[0, -1.15, 0]}
        opacity={0.55}
        scale={6}
        blur={2.6}
        far={2}
        color="#000000"
      />
    </>
  );
}

function Rig({ pointer }: { pointer: React.MutableRefObject<{ x: number; y: number }> }) {
  const { camera } = useThree();
  useFrame(() => {
    camera.position.x = THREE.MathUtils.lerp(camera.position.x, pointer.current.x * 0.6, 0.04);
    camera.position.y = THREE.MathUtils.lerp(camera.position.y, 0.2 + pointer.current.y * 0.3, 0.04);
    camera.lookAt(0, -0.1, 0);
  });
  return null;
}

export default function SneakerScene() {
  const pointer = useMemo(() => ({ current: { x: 0, y: 0 } }), []);

  const handlePointerMove = (e: React.PointerEvent) => {
    const { innerWidth, innerHeight } = window;
    pointer.current.x = (e.clientX / innerWidth - 0.5) * 2;
    pointer.current.y = (e.clientY / innerHeight - 0.5) * 2;
  };

  return (
    <div className="h-full w-full" onPointerMove={handlePointerMove}>
      <Canvas
        shadows
        camera={{ position: [0, 0.2, 4.2], fov: 32 }}
        gl={{ antialias: true, alpha: true }}
        dpr={[1, 1.8]}
      >
        <ambientLight intensity={0.35} />
        <directionalLight position={[-3, 2, -2]} intensity={0.4} color="#8f9096" />
        <SneakerModel pointer={pointer} />
        <Rig pointer={pointer} />
        <Environment preset="city" />
      </Canvas>
    </div>
  );
}
