"use client";

import { useRef } from "react";
import { motion, useMotionValue, useSpring, useTransform } from "framer-motion";
import type { Product } from "@/lib/data";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function ProductCard({
  product,
  onOpen,
}: {
  product: Product;
  onOpen: (p: Product) => void;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const mx = useMotionValue(0.5);
  const my = useMotionValue(0.5);

  const spring = { stiffness: 220, damping: 22, mass: 0.5 };
  const rotateX = useSpring(useTransform(my, [0, 1], [8, -8]), spring);
  const rotateY = useSpring(useTransform(mx, [0, 1], [-10, 10]), spring);
  const glowX = useTransform(mx, [0, 1], ["0%", "100%"]);
  const glowY = useTransform(my, [0, 1], ["0%", "100%"]);

  const handleMove = (e: React.MouseEvent) => {
    const rect = ref.current?.getBoundingClientRect();
    if (!rect) return;
    mx.set((e.clientX - rect.left) / rect.width);
    my.set((e.clientY - rect.top) / rect.height);
  };

  const reset = () => {
    mx.set(0.5);
    my.set(0.5);
  };

  return (
    <motion.div
      ref={ref}
      data-cursor="text"
      onMouseMove={handleMove}
      onMouseLeave={reset}
      onClick={() => onOpen(product)}
      initial={{ opacity: 0, y: 60 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, amount: 0.3 }}
      transition={{ duration: 1, ease: EASE }}
      style={{ rotateX, rotateY, transformPerspective: 1200 }}
      className="group relative flex h-[62vh] min-h-[420px] cursor-pointer flex-col justify-end overflow-hidden rounded-[2px] border border-white/[0.06] bg-graphite/40"
      whileHover={{ y: -10, scale: 1.015 }}
    >
      {/* radial glow following cursor */}
      <motion.div
        className="pointer-events-none absolute inset-0 z-10 opacity-0 transition-opacity duration-500 group-hover:opacity-100"
        style={{
          background: `radial-gradient(420px circle at ${glowX} ${glowY}, rgba(216,217,219,0.14), transparent 60%)`,
        }}
      />

      <motion.div
        className="absolute inset-0 z-0"
        animate={{ scale: 1 }}
        whileHover={{ scale: 1.08 }}
        transition={{ duration: 0.8, ease: EASE }}
      >
        <img
          src={product.image}
          alt={product.name}
          className="h-full w-full object-cover opacity-70 grayscale transition-all duration-700 group-hover:opacity-90 group-hover:grayscale-0"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-void via-void/30 to-void/10" />
      </motion.div>

      <div className="relative z-20 flex items-start justify-between p-8">
        <span className="font-mono text-[10px] tracking-widest2 text-ash">
          {product.index}
        </span>
        <span className="font-mono text-[10px] tracking-widest2 text-ash">
          {product.category.toUpperCase()}
        </span>
      </div>

      <div className="relative z-20 flex-1" />

      <div className="relative z-20 p-8">
        <h3 className="font-display text-3xl font-700 tracking-tight text-bone md:text-4xl">
          {product.name}
        </h3>

        <div className="mt-3 max-h-0 overflow-hidden opacity-0 transition-all duration-500 ease-premium group-hover:mt-4 group-hover:max-h-24 group-hover:opacity-100">
          <p className="max-w-xs font-body text-xs font-light leading-relaxed text-silver-dim">
            {product.description}
          </p>
        </div>

        <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4">
          <span className="font-mono text-xs tracking-widest2 text-smoke">
            {product.price}
          </span>
          <span className="font-mono text-[10px] tracking-widest2 text-ash transition-colors group-hover:text-bone">
            VIEW →
          </span>
        </div>
      </div>
    </motion.div>
  );
}
