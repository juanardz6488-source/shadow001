"use client";

import { useState } from "react";
import { motion } from "framer-motion";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function Footer() {
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
  };

  return (
    <footer className="relative z-10 flex min-h-[100svh] w-full flex-col justify-between overflow-hidden bg-void px-6 pb-10 pt-24 md:px-16">
      <div className="flex flex-col items-center gap-10 text-center">
        <svg width="26" height="26" viewBox="0 0 60 60" fill="none" className="opacity-80">
          <path d="M2 46L14 20L20 33L10 46H2Z" fill="#F2F2F0" />
          <path d="M22 46L34 14L40 27L30 46H22Z" fill="#F2F2F0" />
          <path d="M42 46L52 27L58 40L54 46H42Z" fill="#F2F2F0" />
        </svg>

        <div className="mask-reveal">
          <motion.h2
            initial={{ y: "100%" }}
            whileInView={{ y: "0%" }}
            viewport={{ once: true, amount: 0.5 }}
            transition={{ duration: 1.1, ease: EASE }}
            className="font-display text-[9vw] font-800 leading-[0.9] tracking-tightest text-bone md:text-[4.5vw]"
          >
            SEE YOU AT THE
            <br />
            NEXT DROP.
          </motion.h2>
        </div>

        {!submitted ? (
          <form
            onSubmit={handleSubmit}
            className="flex w-full max-w-sm items-center gap-4 border-b border-white/20 pb-3"
          >
            <input
              data-cursor="text"
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="YOUR EMAIL"
              className="w-full bg-transparent font-mono text-xs tracking-widest2 text-bone placeholder:text-ash focus:outline-none"
            />
            <button
              data-cursor="hover"
              type="submit"
              className="font-mono text-xs tracking-widest2 text-bone transition-opacity hover:opacity-60"
            >
              JOIN →
            </button>
          </form>
        ) : (
          <p className="font-mono text-xs tracking-widest2 text-silver-dim">
            YOU'RE ON THE LIST.
          </p>
        )}
      </div>

      <div className="mt-24 flex flex-col items-center justify-between gap-6 border-t border-white/10 pt-8 font-mono text-[10px] tracking-widest2 text-ash md:flex-row">
        <span>SHADOW//001 — CONCEPT DROP</span>
        <div className="flex gap-6">
          <a data-cursor="hover" href="#" className="transition-colors hover:text-bone">
            INSTAGRAM
          </a>
          <a data-cursor="hover" href="#" className="transition-colors hover:text-bone">
            X
          </a>
          <a data-cursor="hover" href="#" className="transition-colors hover:text-bone">
            TIKTOK
          </a>
        </div>
        <span>© 2026</span>
      </div>

      <p className="mt-6 text-center font-mono text-[9px] tracking-widest2 text-ash/60">
        UNOFFICIAL FAN-MADE CONCEPT PROJECT. NOT AFFILIATED WITH OR ENDORSED BY ADIDAS AG.
      </p>
    </footer>
  );
}
