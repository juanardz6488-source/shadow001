"use client";

import { useEffect, useRef, useState } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

export default function CustomCursor() {
  const [variant, setVariant] = useState<"default" | "hover" | "drag" | "text">("default");
  const [visible, setVisible] = useState(false);

  const mouseX = useMotionValue(-100);
  const mouseY = useMotionValue(-100);
  const springConfig = { damping: 28, stiffness: 320, mass: 0.4 };
  const x = useSpring(mouseX, springConfig);
  const y = useSpring(mouseY, springConfig);

  const dotX = useSpring(mouseX, { damping: 40, stiffness: 900 });
  const dotY = useSpring(mouseY, { damping: 40, stiffness: 900 });

  useEffect(() => {
    const move = (e: MouseEvent) => {
      mouseX.set(e.clientX);
      mouseY.set(e.clientY);
      if (!visible) setVisible(true);
    };

    const onOver = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      if (target.closest("[data-cursor='hover']")) setVariant("hover");
      else if (target.closest("[data-cursor='drag']")) setVariant("drag");
      else if (target.closest("[data-cursor='text']")) setVariant("text");
      else setVariant("default");
    };

    window.addEventListener("mousemove", move);
    window.addEventListener("mouseover", onOver);
    return () => {
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseover", onOver);
    };
  }, [mouseX, mouseY, visible]);

  const sizes = {
    default: 16,
    hover: 64,
    drag: 88,
    text: 40,
  };

  return (
    <div
      className="pointer-events-none fixed inset-0 z-[300] hidden md:block"
      style={{ opacity: visible ? 1 : 0 }}
    >
      <motion.div
        className="fixed rounded-full border border-silver/70 mix-blend-difference"
        style={{
          x,
          y,
          translateX: "-50%",
          translateY: "-50%",
        }}
        animate={{
          width: sizes[variant],
          height: sizes[variant],
          backgroundColor:
            variant === "hover" || variant === "drag"
              ? "rgba(216,217,219,0.08)"
              : "rgba(0,0,0,0)",
        }}
        transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
      >
        {variant === "drag" && (
          <span className="absolute inset-0 flex items-center justify-center font-mono text-[9px] tracking-widest2 text-bone">
            DRAG
          </span>
        )}
        {variant === "text" && (
          <span className="absolute inset-0 flex items-center justify-center font-mono text-[9px] tracking-widest2 text-bone">
            VIEW
          </span>
        )}
      </motion.div>
      <motion.div
        className="fixed h-1.5 w-1.5 rounded-full bg-bone mix-blend-difference"
        style={{
          x: dotX,
          y: dotY,
          translateX: "-50%",
          translateY: "-50%",
        }}
      />
    </div>
  );
}
