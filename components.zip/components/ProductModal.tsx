"use client";

import { AnimatePresence, motion } from "framer-motion";
import type { Product } from "@/lib/data";

const EASE = [0.16, 1, 0.3, 1] as const;

export default function ProductModal({
  product,
  onClose,
}: {
  product: Product | null;
  onClose: () => void;
}) {
  return (
    <AnimatePresence>
      {product && (
        <motion.div
          className="fixed inset-0 z-[220] flex items-center justify-center bg-void/95 backdrop-blur-xl"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0, transition: { duration: 0.5, ease: EASE } }}
          onClick={onClose}
        >
          <motion.button
            data-cursor="hover"
            onClick={onClose}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="absolute right-8 top-8 z-10 font-mono text-[10px] tracking-widest2 text-ash transition-colors hover:text-bone"
          >
            CLOSE ✕
          </motion.button>

          <motion.div
            onClick={(e) => e.stopPropagation()}
            initial={{ opacity: 0, scale: 0.92, y: 40 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.95, y: 20, transition: { duration: 0.4, ease: EASE } }}
            transition={{ duration: 0.8, ease: EASE }}
            className="relative grid h-[88vh] w-[92vw] grid-cols-1 overflow-hidden rounded-sm border border-white/10 bg-ink md:grid-cols-2"
          >
            <div className="relative h-full overflow-hidden">
              <motion.img
                key={product.id}
                src={product.image}
                alt={product.name}
                initial={{ scale: 1.15, opacity: 0.6 }}
                animate={{
                  scale: [1.15, 1.02, 1.08, 1.02],
                  opacity: 1,
                }}
                transition={{
                  scale: { duration: 14, ease: "linear", repeat: Infinity },
                  opacity: { duration: 1.2 },
                }}
                className="h-full w-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-ink via-transparent to-ink/40 md:bg-gradient-to-r" />
            </div>

            <div className="relative flex flex-col justify-center gap-6 p-10 md:p-14">
              <span className="font-mono text-[10px] tracking-widest2 text-ash">
                {product.index} / {product.category.toUpperCase()}
              </span>

              <h2 className="font-display text-4xl font-800 leading-[0.95] tracking-tightest text-bone md:text-6xl">
                {product.name}
              </h2>

              <p className="max-w-md font-body text-sm font-light leading-relaxed text-silver-dim">
                {product.description}
              </p>

              <ul className="flex flex-col gap-2 border-t border-white/10 pt-6">
                {product.details.map((d) => (
                  <li
                    key={d}
                    className="flex items-center gap-3 font-mono text-[11px] tracking-wide text-smoke"
                  >
                    <span className="h-px w-4 bg-silver-dim" />
                    {d}
                  </li>
                ))}
              </ul>

              <div className="mt-2 flex items-center justify-between">
                <span className="font-mono text-sm tracking-widest2 text-bone">
                  {product.price}
                </span>
              </div>

              <button
                data-cursor="hover"
                className="group relative mt-2 w-full overflow-hidden border border-white/20 py-5 text-center font-mono text-xs tracking-widest2 text-bone transition-colors duration-500 hover:border-white/60"
              >
                <span className="relative z-10">ENTER DROP</span>
                <motion.span
                  className="absolute bottom-0 left-0 h-px w-full origin-left bg-bone"
                  initial={{ scaleX: 0 }}
                  whileHover={{ scaleX: 1 }}
                  transition={{ duration: 0.6, ease: EASE }}
                />
                <span className="absolute inset-0 -z-0 origin-left scale-x-0 bg-white/5 transition-transform duration-500 group-hover:scale-x-100" />
              </button>
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
