"use client";

import { useEffect, useRef } from "react";

type Particle = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  o: number;
  flicker: number;
};

type Smoke = {
  x: number;
  y: number;
  r: number;
  vx: number;
  vy: number;
  o: number;
  hue: number;
};

export default function AmbientBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const pointer = useRef({ x: 0, y: 0, tx: 0, ty: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let w = (canvas.width = window.innerWidth);
    let h = (canvas.height = window.innerHeight);
    const dpr = Math.min(window.devicePixelRatio || 1, 2);

    const resize = () => {
      w = window.innerWidth;
      h = window.innerHeight;
      canvas.width = w * dpr;
      canvas.height = h * dpr;
      canvas.style.width = w + "px";
      canvas.style.height = h + "px";
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    };
    resize();
    window.addEventListener("resize", resize);

    const particles: Particle[] = Array.from({ length: 90 }, () => ({
      x: Math.random() * w,
      y: Math.random() * h,
      r: Math.random() * 1.4 + 0.3,
      vx: (Math.random() - 0.5) * 0.06,
      vy: -Math.random() * 0.08 - 0.02,
      o: Math.random() * 0.5 + 0.1,
      flicker: Math.random() * Math.PI * 2,
    }));

    const smokes: Smoke[] = Array.from({ length: 5 }, () => ({
      x: Math.random() * w,
      y: h * 0.4 + Math.random() * h * 0.6,
      r: Math.random() * 380 + 260,
      vx: (Math.random() - 0.5) * 0.04,
      vy: (Math.random() - 0.5) * 0.03,
      o: Math.random() * 0.05 + 0.03,
      hue: 0,
    }));

    const onMove = (e: MouseEvent) => {
      pointer.current.tx = (e.clientX / w - 0.5) * 2;
      pointer.current.ty = (e.clientY / h - 0.5) * 2;
    };
    window.addEventListener("mousemove", onMove);

    let raf = 0;
    const tick = () => {
      pointer.current.x += (pointer.current.tx - pointer.current.x) * 0.02;
      pointer.current.y += (pointer.current.ty - pointer.current.y) * 0.02;

      ctx.clearRect(0, 0, w, h);

      // base gradient
      const g = ctx.createRadialGradient(
        w / 2 + pointer.current.x * 60,
        h / 2 + pointer.current.y * 60,
        0,
        w / 2,
        h / 2,
        Math.max(w, h) * 0.75
      );
      g.addColorStop(0, "#101012");
      g.addColorStop(0.55, "#08080a");
      g.addColorStop(1, "#020202");
      ctx.fillStyle = g;
      ctx.fillRect(0, 0, w, h);

      // smoke
      smokes.forEach((s) => {
        s.x += s.vx + pointer.current.x * 0.05;
        s.y += s.vy;
        if (s.x < -s.r) s.x = w + s.r;
        if (s.x > w + s.r) s.x = -s.r;
        if (s.y < -s.r) s.y = h + s.r;
        if (s.y > h + s.r) s.y = -s.r;

        const sg = ctx.createRadialGradient(s.x, s.y, 0, s.x, s.y, s.r);
        sg.addColorStop(0, `rgba(90,92,98,${s.o})`);
        sg.addColorStop(1, "rgba(0,0,0,0)");
        ctx.fillStyle = sg;
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // particles / sparks
      const t = performance.now() * 0.001;
      particles.forEach((p) => {
        p.x += p.vx + pointer.current.x * 0.08;
        p.y += p.vy;
        if (p.y < -10) p.y = h + 10;
        if (p.x < -10) p.x = w + 10;
        if (p.x > w + 10) p.x = -10;

        const flick = 0.55 + 0.45 * Math.sin(t * 2 + p.flicker);
        ctx.beginPath();
        ctx.fillStyle = `rgba(230,231,233,${p.o * flick})`;
        ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // vignette
      const vg = ctx.createRadialGradient(
        w / 2,
        h / 2,
        Math.min(w, h) * 0.3,
        w / 2,
        h / 2,
        Math.max(w, h) * 0.75
      );
      vg.addColorStop(0, "rgba(0,0,0,0)");
      vg.addColorStop(1, "rgba(0,0,0,0.75)");
      ctx.fillStyle = vg;
      ctx.fillRect(0, 0, w, h);

      raf = requestAnimationFrame(tick);
    };
    tick();

    return () => {
      cancelAnimationFrame(raf);
      window.removeEventListener("resize", resize);
      window.removeEventListener("mousemove", onMove);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 z-0 h-full w-full"
      aria-hidden="true"
    />
  );
}
