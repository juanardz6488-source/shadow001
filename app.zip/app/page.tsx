"use client";

import { useState } from "react";
import Preloader from "@/components/Preloader";
import AmbientBackground from "@/components/AmbientBackground";
import Hero from "@/components/Hero";
import DropSection from "@/components/DropSection";
import Crafted from "@/components/Crafted";
import Gallery from "@/components/Gallery";
import Footer from "@/components/Footer";
import ProductModal from "@/components/ProductModal";
import type { Product } from "@/lib/data";

export default function Home() {
  const [loaded, setLoaded] = useState(false);
  const [activeProduct, setActiveProduct] = useState<Product | null>(null);

  return (
    <main className="relative min-h-screen bg-void">
      <Preloader onDone={() => setLoaded(true)} />
      <AmbientBackground />

      <div
        style={{
          opacity: loaded ? 1 : 0,
          transition: "opacity 1.2s cubic-bezier(0.16,1,0.3,1)",
        }}
      >
        <Hero />
        <DropSection onOpen={setActiveProduct} />
        <Crafted />
        <Gallery />
        <Footer />
      </div>

      <ProductModal product={activeProduct} onClose={() => setActiveProduct(null)} />
    </main>
  );
}
